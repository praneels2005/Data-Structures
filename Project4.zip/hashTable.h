#include <iostream>
#include "SLL.h"
using  namespace  std;

template <class V>
class HashTable {
    int tableSize; // table size
    
    SLL<V>* table;
    
    public:
    // default constructor, which uses default table size 3
    HashTable(){
        tableSize = 3;
        table = new SLL<V>[tableSize];
    }
    
    // constructor, which use size as the table size
    HashTable(int size){
        tableSize = size;
        table = new SLL<V>[tableSize];
    }
    
    // search item in the table
    // if found, return true; otherwise, return false
    bool find(V item)
    {
        int pos = stoi(item) % tableSize;
        
        if( table[pos].search(item) != NULL)
        {
            return true;
        }
        return false;
    }
    
    // insert (item1, item2) to the table
    // use item1 as the key
    // if inserted, return true
    // otherwise, return false
    bool insert(V item1, V item2){
        int pos = stoi(item1) % tableSize;
        
        int tempSize = table[pos].getSize();
        
        table[pos].insert(item1, item2);
        
        int newSize = table[pos].getSize();
        if(newSize > tempSize)
        {
            return true;
        }
        return false;
        
    }
    
    // delete the pair whose key value is item
    // if deleted, return true
    // otherwise, return false 
    bool erase(V item)
    {
        int pos = stoi(item) % tableSize;
        
        return table[pos].remove(item);
      // implement this method
    }

    // return the total number of nodes in the hash table    
    int getSize()
    {
        int totalNodes = 0;
        for(int i = 0; i<tableSize; i++)
        {
            totalNodes += table[i].getSize();
        }
        return totalNodes;
      // implement this method
    }

};

#include <iostream>
#include <fstream>
#include "hashTable.h"
#include <string>
#include <time.h>
#include <ctime>

using namespace std;

int main(int argc, char* argv[])
{

  // implement this missing part
  // make the array size inside the hash table is 10007
    
    fstream input;
    input.open(argv[1]);
    char IDR;
    string Name;
    string SSN;
    string First;
    string Last;
    
    int insertionCount;
    int deletionCount;
    int retrievalCount;
    
    HashTable<string>* Table = new HashTable<string>(10007);
    
    clock_t start, end;
    double duration;

    start = clock();
    
    while(!input.eof())
    {
        input>>IDR;
        
        input>>SSN;
        input>>First;
        input>>Last;
        
        Name = First + " " + Last;
        
        switch(IDR)
        {
            case 'i':
                {
                    if(Table->insert(SSN, Name))
                    {
                        insertionCount++;
                    }
                    break;
                }
            case 'd':
                {
                    if(Table->erase(SSN))
                    {
                        deletionCount++;
                    }
                    break;
                }
            case 'r':
                {
                    if(Table->find(SSN))
                    {
                        retrievalCount++;
                    }
                    break;
                }
        }
    }
    
    end = clock();
    duration = ( end - start ) / (double) CLOCKS_PER_SEC;
      cout<< "The Number of Valid Insertation: " <<insertionCount<<endl;
      cout<< "The Number of Valid Deletion: "<<deletionCount<<endl;
      cout<< "The Number of Valid Retrieval: "<<retrievalCount<<endl;
      cout<<"Item numbers in the list: "<< Table->getSize()<<endl;
    cout<<"Time elapsed: "<< duration <<'\n';
}

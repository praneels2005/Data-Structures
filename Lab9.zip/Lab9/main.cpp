#include "PriorityQueue.h"
#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char* argv[])
{
  //decalre a priority queue
  PriorityQueue< IRSEntry<string> > pq;

  // open file
  fstream input;
  input.open(argv[1]);

  // declare input variables
  char command;
  string ssn;
  string firstName;
  string lastName;

  // read file
  while (!input.eof())
  {
    input >> command;
    input >> ssn;
    input >> firstName;
    input >> lastName;

    // create an instance of info
    IRSEntry<string> info;
    info.ssn = ssn;
    info.name = firstName + " " + lastName;

    //push in the priority queue
    pq.push(info);

  }
  //reading everything from the priority queue
  cout << "Contents of the priority queue:" << endl;
  while (!pq.empty())
  {
    IRSEntry<string> front = pq.front();
    cout << front.ssn << ": " << front.name << endl;
    //remove the front entry
    pq.pop();
  }

  return 0;
}


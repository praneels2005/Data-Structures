#include<iostream>
#include<cassert>
using namespace std;

template <class T>
struct IRSEntry {
  T ssn;
  T name;
};

template<class T>
struct Node
{
  T data;
  Node<T>* next;
};

template<class ItemType>
class PriorityQueue
{
private:
  Node<ItemType>* headPtr;

public:
  PriorityQueue();
  bool empty() const;
  ItemType front() const;
  void push(const ItemType& newEntry);
  void pop();
  void print();
};

template<class ItemType>
PriorityQueue<ItemType>::PriorityQueue()
{
  headPtr = NULL;
}

template<class ItemType>
bool PriorityQueue<ItemType>::empty() const
{
  return headPtr == NULL;
}

template<class ItemType>
ItemType PriorityQueue<ItemType>::front() const
{
  assert(!empty());
  return headPtr->data;
}

template<class ItemType>
void PriorityQueue<ItemType>::push(const ItemType& newEntry)
{
  //create new node
    Node <ItemType>* NewNode = new Node<ItemType>;
    NewNode->data = newEntry;
    NewNode->next = NULL;

  //if PriorityQueue is empty
    if(empty())
    {
        headPtr = NewNode;
    }
    //if current ssn is less than the headPtr
    else if((NewNode->data.ssn).compare(headPtr->data.ssn) <0)
    {
        Node <ItemType>*temp = headPtr;
        NewNode->next = temp;
        headPtr = NewNode;
    }
    else
    {
        Node <ItemType>*curr = headPtr->next;
        Node <ItemType>*prev = headPtr;
        while(curr != NULL)
        {
            //insert at the middle
            if((NewNode->data.ssn).compare(curr->data.ssn) <0)
            {
                NewNode->next = curr;
                prev->next = NewNode;
                break;
            }
            prev = curr;
            curr = curr->next;
        }
        
        //insert at the end
        if(curr == NULL)
        {
            prev->next = NewNode;
        }
        
    }

}

template<class ItemType>
void PriorityQueue<ItemType>::pop()
{
    if(!empty())
    {
        
        //don't forget to delete the popped node
          Node <ItemType>* temp = headPtr;
          headPtr = temp->next;
        delete temp;
          //temp = NULL;
        
    }
    
  
}


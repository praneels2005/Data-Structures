#include "DLL.h"
#include <iostream>
#include <string>
using namespace std;

// default constructor is already implemented
// do not modify the default constructor
DLL::DLL(){
    headPtr = nullptr;
    itemCount=0;
}

// return the head pointer of the list
// it is already implemented, do not modify it
Node* DLL::getHeadPtr(){
    return headPtr;
}

// copy construct, which copies an existing list n
// the new list is a different object from n
// the new list and object n have the same contents
// Please implement it
DLL::DLL(DLL& n)
{
    //headPtr = new Node;
    Node * temp = n.getHeadPtr();
    int count = 0;
    //insert(temp->ssn, temp->name, count);
    while(temp != NULL)
    {
        insert(temp->ssn, temp->name, count);
        temp = temp->succ;
    }
}

// destructor
// release every node of the list
// Please implement it
DLL::~DLL()
{
    Node *temp = headPtr;
    while(temp != NULL)
    {
        Node *temp2 = temp->succ;
        delete temp;
        temp = temp2;
    }

}

// if some node has SSN matcthes string ss
// return the index value of the node
// the index value of the first node is 0, the second node is 1, etc.
// if there is not node matching ss, return -1
int DLL::search(string ss)const
{
        Node *temp = headPtr;
        int index = 0;
        while(temp != NULL)
        {
            if((temp->ssn).compare(ss) == 0)
            {
                return index;
            }
            else
            {
                index++;
                temp = temp->succ;
            }
        }
        return -1;
}


// insert (ss, name) to the existing list
// the SSN values are each node are organized in INCREASING order
// if there is a node matching ss value, return false; otherwise true
// else create a node with (ss, name), insert the node to the proper position
// parameter count is the counter of number of valid insertion
// when you implement this method, consider the following situations:
// 1. list is empty
// 2. node should be inserted to the beginning of the list
// 3. node should be inserted to the middle of the list
// 4. node should be inserted to the end of the list
bool DLL::insert(string ss, string name, int & count)
{
    if(search(ss) == -1)
    {
            Node * NewNode = new Node;
            NewNode->ssn = ss;
            NewNode->name = name;
            NewNode->succ = NULL;
            NewNode->pred = NULL;
        
            Node *temp = headPtr;

            if(headPtr == NULL)
                {
                    headPtr = NewNode;
                    count++;
                    itemCount++;
                    return true;
                }
            else if((NewNode->ssn).compare(temp->ssn)<0)
                {
                    NewNode->succ = temp;
                    temp->pred = NewNode;
                    headPtr = NewNode;
                    count++;
                    itemCount++;
                    return true;
                }
            else
                {
                    Node* temp2 = temp->succ;
                    while(temp2 != NULL)
                    {
                        if((NewNode->ssn).compare(temp2->ssn)<0)
                        {
                            NewNode->succ = temp2;
                            NewNode->pred = temp;
                            temp->succ = NewNode;
                            temp2->pred = NewNode;
                            count++;
                            itemCount++;
                            return true;
                        }
                        temp = temp2;
                        temp2 = temp2->succ;
                    }
                    temp->succ = NewNode;
                    NewNode->pred = temp;
                    count++;
                    itemCount++;
                    return true;
                }
    }
    
    return false;
    
    }


// remove node containing ss value
// if there is no node containing ss, return false; otherwise true
// consider the following situations:
// 1. list is empty
// 2. node containing ss value is the first node
// 3. node containing ss value is in the middle of the list
// 4. node containing ss value is the last node of the list
bool DLL::remove(string ss, int & count)
{
    if(search(ss) != -1 && headPtr != NULL)
    {
        Node *temp = headPtr;
        Node *temp2 = temp->succ;
        if(temp2 == NULL)
        {
            if((temp->ssn).compare(ss) == 0)
            {
                delete temp;
                count++;
                itemCount--;
                return true;
            }
        }
        else if((temp->ssn).compare(ss) == 0)
        {
            temp2->pred = NULL;
            headPtr = temp2;
            delete temp;
            count++;
            itemCount--;
            return true;
        }
        else
        {
            Node * temp3 = temp2->succ;
            while(temp3 != NULL)
            {
                if((temp2->ssn).compare(ss) == 0)
                {
                    temp3->pred = temp;
                    temp->succ = temp3;
                    delete temp2;
                    count++;
                    itemCount--;
                    return true;
                }
                temp = temp2;
                temp2 = temp3;
                temp3 = temp3->succ;
            }
            if((temp2->ssn).compare(ss) == 0)
            {
                temp->succ = NULL;
                delete temp2;
                count++;
                return true;
            }
        }
    }
        return false;
}

// return the number of the nodes
// it is already implemented, do not modify it
int DLL::size(){
    
    return itemCount;
}

// iterate through each node
// print out SSN and memory address of each node
// do not modify this method
void DLL::display(){
    Node* temp;
    temp = headPtr;
    while (temp!= nullptr) {
        cout << temp->ssn << "\t" << temp << endl;
        temp = temp->succ;
    }
}

#include "DLL.h"
#include <iostream>
#include <cstdio>
#include <ctime>
#include <fstream>
//#include "DLL.cpp"
using namespace std;

int main(int argc, char*argv[])
{
    fstream input;
    input.open(argv[1]);
    char IDR;
    string Name;
    string SSN;
    string First;
    string Last;
    
    int insertionCount = 0;
    int deletionCount = 0;
    int retrievalCount = 0;
    DLL People;
    
  clock_t start, end;
  double duration;

  start = clock();

    while(!input.eof())
    {
        input>>IDR;
        
        input>>SSN;
        input>>First;
        input>>Last;
        
        Name = First + " " + Last;
        
        switch(IDR)
        {
            case 'i':
                {
                    People.insert(SSN, Name, insertionCount);
                    break;
                }
            case 'd':
                {
                    People.remove(SSN, deletionCount);
                    break;
                }
            case 'r':
                {
                    if(People.search(SSN) > 0)
                    {
                        retrievalCount++;
                    }
                    break;
                }
        }
    }
    
  end = clock();
  duration = ( end - start ) / (double) CLOCKS_PER_SEC;
    cout<< "The Number of Valid Insertation: " <<insertionCount<<endl;
    cout<< "The Number of Valid Deletion: "<<deletionCount<<endl;
    cout<< "The Number of Valid Retrieval: "<<retrievalCount<<endl;
    cout<<"Item numbers in the list: "<< People.size()<<endl;
  cout<<"Time elapsed: "<< duration <<'\n';
}

